from OpenGL.GL import *
from OpenGL.GLUT import *
from OpenGL.GLU import *
import random
import time

# Catcher coordinates
x1, x2, x3, x4 = 20, 50, 200, 230
y1, y2 = 10, 50

# Diamond variables
diamond_x = random.uniform(10, 490)
diamond_y = 500
fall_speed = 100  # initial fall speed
fall_acceleration = 20  # fall acceleration per successful catch
fall_speed_cap = 300  # maximum fall speed

# Game states
pause_flag = False  # pause
start_flag = True   # start initially true to run the game
over_flag = False   # game over

# Score
score_count = 0

# Catcher speed
catcher_speed = 200  # initial catcher speed

# Delta timing
last_time = time.time()

def draw_points(x, y):
    glPointSize(2)
    glBegin(GL_POINTS)
    glVertex2f(x, y)
    glEnd()

def findzone(x1, y1, x2, y2):
    dx = x2 - x1
    dy = y2 - y1
    zone = -1

    if abs(dx) > abs(dy):
        if dx > 0 and dy > 0:
            zone = 0
        elif dx < 0 and dy > 0:
            zone = 3
        elif dx < 0 and dy < 0:
            zone = 4
        else:
            zone = 7
    else:
        if dx > 0 and dy > 0:
            zone = 1
        elif dx < 0 and dy > 0:
            zone = 2
        elif dx < 0 and dy < 0:
            zone = 5
        else:
            zone = 6
    return zone

def convertToZone0(zone, x, y):
    if (zone == 0):
        return x, y
    elif (zone == 1):
        return y, x                # swap of 0
    elif (zone == 2):
        return -y, x               # swap of 3
    elif (zone == 3):
        return -x, y
    elif (zone == 4):
        return -x, -y
    elif (zone == 5):              # swap of 4
        return -y, -x
    elif (zone == 6):              # swap of 7
        return -y, x
    elif (zone == 7):
        return x, -y

def convertBackOriginalZone(zone, x, y):
    if (zone == 0):
        return x, y
    elif (zone == 1):
        return y, x
    elif (zone == 2):
        return -y, -x
    elif (zone == 3):
        return -x, y
    elif (zone == 4):
        return -x, -y
    elif (zone == 5):
        return -y, -x
    elif (zone == 6):
        return y, -x
    elif (zone == 7):
        return x, -y

def midpointLine(zone, x1, y1, x2, y2):
    dx = x2 - x1
    dy = y2 - y1
    d = 2 * dy - dx
    dNE = 2 * (dy - dx)
    dE = 2 * dy

    x, y = x1, y1
    while x <= x2:
        cx, cy = convertBackOriginalZone(zone, x, y)     # points of convert back to original zone
        draw_points(cx, cy)
        x += 1
        if d > 0:
            y += 1
            d = d + dNE
        else:
            d = d + dE

def draw_line_8way(x1, y1, x2, y2):
    zone = findzone(x1, y1, x2, y2)
    x1, y1 = convertToZone0(zone, x1, y1)
    x2, y2 = convertToZone0(zone, x2, y2)
    midpointLine(zone, x1, y1, x2, y2)

def draw_catcher():
    global x1, x2, x3, x4, y1, y2
    glColor3f(1.0, 1.0, 1.0)
    draw_line_8way(x2, y1, x3, y1)
    draw_line_8way(x1, y2, x2, y1)
    draw_line_8way(x3, y1, x4, y2)
    draw_line_8way(x1, y2, x4, y2)

def specialKeyListener(key, x, y):
    global x1, x2, x3, x4, y1, y2, pause_flag, delta_time
    move = 10
    if not pause_flag:
        if key == GLUT_KEY_RIGHT:
            if x4 + catcher_speed * delta_time <= 500:
                x1 += move
                x2 += move
                x3 += move
                x4 += move
        if key == GLUT_KEY_LEFT:
            if x1 - catcher_speed * delta_time >= 0:
                x1 -= move
                x2 -= move
                x3 -= move
                x4 -= move
    glutPostRedisplay()

def hasCollided(box1, box2):
    return (box1[0] < box2[0] + box2[2] and
            box1[0] + box1[2] > box2[0] and
            box1[1] < box2[1] + box2[3] and
            box1[1] + box1[3] > box2[1])

def check_collision(d_x, d_y):
    global score_count, over_flag
    catcher_box = [x1, y1, x4 - x1, y2 - y1]
    diamond_box = [d_x - 10, d_y - 10, 20, 20]
    if hasCollided(catcher_box, diamond_box):
        score_count += 1
        print(f"Score: {score_count}")
        return True
    return False

def draw_diamond(d_x, d_y):
    glColor3f(1.0, 0.0, 0.5)
    draw_line_8way(d_x - 10, d_y - 10, d_x, d_y + 10)
    draw_line_8way(d_x, d_y + 10, d_x + 10, d_y - 10)
    draw_line_8way(d_x - 10, d_y - 10, d_x + 10, d_y - 10)

def left_arrow():
    glColor3f(0.0, 1.0, 1.0)
    draw_line_8way(50, 425, 100, 425)
    draw_line_8way(70, 430, 50, 425)
    draw_line_8way(70, 420, 50, 425)

def cross():
    glColor3f(1.0, 0.0, 0.0)
    draw_line_8way(400, 400, 450, 450)
    draw_line_8way(400, 450, 450, 400)

def play():
    glColor3f(1.0, 1.0, 0.0)
    draw_line_8way(250, 450, 250, 400)
    draw_line_8way(255, 450, 255, 400)

def pause():
    glColor3f(1.0, 1.0, 0.0)
    draw_line_8way(250, 450, 250, 400)
    draw_line_8way(250, 450, 270, 425)
    draw_line_8way(250, 400, 270, 425)

def mouseListener(button, state, x, y):
    global pause_flag, start_flag, over_flag, x1, x2, x3, x4, score_count
    new_y = 500 - y
    if button == GLUT_LEFT_BUTTON and state == GLUT_DOWN:
        if 250 <= x <= 270 and 400 <= new_y <= 450:
            pause_flag = not pause_flag
            if pause_flag:
                print(f"Paused Score: {score_count}")
            else:
                print(f"Resumed Score: {score_count}")
        if 400 <= x <= 450 and 400 <= new_y <= 450:
            over_flag = True
            print(f"Game Over! Total Score: {score_count}")
            glutLeaveMainLoop()

def animation():
    global start_flag, pause_flag
    if start_flag and not pause_flag:
        glutPostRedisplay()

def iterate():
    glViewport(0, 0, 500, 500)
    glMatrixMode(GL_PROJECTION)
    glLoadIdentity()
    glOrtho(0.0, 500, 0.0, 500, 0.0, 1.0)
    glMatrixMode(GL_MODELVIEW)
    glLoadIdentity()

def showScreen():
    global score_count, over_flag, fall_speed, diamond_x, diamond_y, last_time, delta_time
    current_time = time.time()
    delta_time = current_time - last_time
    last_time = current_time
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
    glLoadIdentity()
    iterate()
    draw_catcher()
    left_arrow()
    cross()
    if start_flag:
        if diamond_y < 0:
            over_flag = True
            print(f"Game Over! Total Score: {score_count}")
            glutLeaveMainLoop()
        diamond_y -= fall_speed * delta_time
        draw_diamond(diamond_x, diamond_y)
        if check_collision(diamond_x, diamond_y):
            diamond_y = 500
            diamond_x = random.uniform(10, 490)
            fall_speed = min(fall_speed + fall_acceleration, fall_speed_cap)  # Increase speed with cap
    if pause_flag:
        pause()
    else:
        play()
    glutSwapBuffers()

glutInit()
glutInitDisplayMode(GLUT_RGBA)
glutInitWindowSize(500, 500)  # window size
glutInitWindowPosition(0, 0)
wind = glutCreateWindow(b"Diamond Catching")  # window name
glutDisplayFunc(showScreen)
glutSpecialFunc(specialKeyListener)
glutMouseFunc(mouseListener)
glutIdleFunc(animation)
glutMainLoop()
